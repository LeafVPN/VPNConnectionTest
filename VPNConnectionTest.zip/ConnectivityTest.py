#!/usr/bin/env python
__author__ = 'Patricio Cano'


import ConnectionTestClass as vpn
#vpnuser and vpnpass must be set before proceeding

testAgent = vpn.ConnectionTestClass(vpnuser='user@uni-stuttgart.de', vpnpass='passwd')
testAgent.beginTest()
